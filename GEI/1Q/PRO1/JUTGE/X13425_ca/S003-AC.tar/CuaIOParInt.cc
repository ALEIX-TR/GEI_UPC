#include "CuaIOParInt.hh"
#include <iostream>
using namespace std;

void llegirCuaParInt(queue<ParInt>& c) {
    ParInt x;
    while (x.llegir()) {
        c.push(x);
    }
}

void escriureCuaParInt(queue<ParInt> c) {
    while (!c.empty()) {
        c.front().escriure();
        c.pop();
    }
}