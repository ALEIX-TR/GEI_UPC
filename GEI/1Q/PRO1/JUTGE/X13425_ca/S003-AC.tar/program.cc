#include "ParInt.hh"
#include "CuaIOParInt.hh"
#include <iostream>
#include <queue>
using namespace std;

int main() {
    queue<ParInt> F1;
    queue<ParInt> F2;
    int TF1, TF2;
    TF1 = TF2 = 0;
    ParInt X;
    while (X.llegir()) {
        if (TF1 > TF2) {F2.push(X); TF2 += X.segon();}
        else {F1.push(X); TF1 += X.segon();}
    }
    escriureCuaParInt(F1);
    cout << endl;
    escriureCuaParInt(F2);
}